
package hw2_allison_broski;

import java.util.*;
/**
 *
 * @author Allison
 */
//Prompt 1a - Create a class called Card. Here it is!
//Prompt 2 - Card Class Details

public class Card {
    //Current value of the card; Prompt 2a
    private int nowCard; 
    //Highest value a card can be; Prompt 2a
    private int maxCard; 
    //Creating a random number generator
    Random card = new Random(); 
    
    //Prompt 2b
    //int cardMax is the max card value we can have.
    public Card(int cardMax)
    {
        //Set the max value to the input highest card value
        maxCard = cardMax; 
        //Assigning the current value of a card to a random value
        nowCard = card.nextInt(maxCard)+1; 
    }
    
    //Prompt 2c - return the value of the card to use in the main code
    public int getCardValue() 
    {
       return nowCard;
    }
    
    //Prompt 2d - Sets the nowCard to a random value
    public void flipCard() 
    {
        nowCard = card.nextInt(maxCard)+1;
    }
    
    //Prompt 2e - Returns a string containing only the instance variables
    public String toString() 
    {
        String instanceFinal = "Current card value is: " + nowCard + ". Max card "
                + "value is: " + maxCard;
        return instanceFinal;
        
    }
    
    
    
}

