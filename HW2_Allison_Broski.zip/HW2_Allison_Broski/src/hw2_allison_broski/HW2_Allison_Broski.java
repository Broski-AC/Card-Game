package hw2_allison_broski;

//Import packages to make all the important stuff run
import java.util.Optional;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.geometry.VPos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.control.TextInputDialog;
import javafx.scene.layout.GridPane;
import javafx.scene.text.Text;
import javafx.stage.Stage;

/**
 *
 * @author Allison
 */
public class HW2_Allison_Broski extends Application {
    
    //Prompt 1: Create a JavaFX program. Here's my program!

    //Prompt 3dvii - Label to display the number of wins
    int wins;
    //Prompt 3div - Textbox for user input
    TextField txtuserGuess = new TextField();
    //Variable to hold the maximum value the user wants to use for the card game - Prompt 3
    int maximum;

    // Creating 4 card variables
    Card eineCard;
    Card zweiCard;
    Card dreiCard;
    Card vierCard;

    //Creating four labels for my gridpane
    Label lblcardEine = new Label("Card 1");
    Label lblcardZwei = new Label("Card 2");
    Label lblcardDrei = new Label("Card 3");
    Label lblcardVier = new Label("Card 4");

    //Three of the labels for displaying the card sum and the win/loose result
    Label lblSumCard = new Label();
    Label lblWinLoose = new Label();
    Label lblWinNumber = new Label("Wins " + wins);

    @Override
    public void start(Stage primaryStage) {

        //This requests input from a user using a TextInputDialog box.
        //Prompt 3a
        TextInputDialog inputBox = new TextInputDialog();
        inputBox.setTitle("HW2 Allison Broski");
        inputBox.setHeaderText(null);
        inputBox.setContentText("Please enter a maximum potential card value for this card game:");

        /*Here, the user is able to input a value, and it is converted to an integer for use 
          later in the program.
         */
        //Prompt 3b -Input the value
        Optional<String> input = inputBox.showAndWait(); 
        if (input.isPresent()) {
            maximum = Integer.parseInt(input.get());
        }
        
        //Prompt 3c - Creating 4 card objects with the same max value
        eineCard = new Card(maximum);
        zweiCard = new Card(maximum);
        dreiCard = new Card(maximum);
        vierCard = new Card(maximum);


        //Prompt 3d - Setting up the main user interface on a GridPane
        GridPane mygrid = new GridPane();
        //Making it a pretty blue color
        mygrid.setStyle("-fx-background-color: #BAEFFF");

        //Details and spaing
        mygrid.setPadding(new Insets(10, 10, 10, 10));
        mygrid.setHgap(10);
        mygrid.setVgap(10);

        //Prompt 3di - Title which includes the max card value
        Text sceneHeader = new Text("'What's the Lucky Number' Card Game. Max Card Value: "
                + maximum);
        //Setting the scaling and orientation of the title
        mygrid.add(sceneHeader, 1, 0, 4, 1);
        GridPane.setHalignment(sceneHeader, HPos.CENTER);
        GridPane.setValignment(sceneHeader, VPos.TOP);
        mygrid.setAlignment(Pos.TOP_CENTER);

        //Prompt 3dii - Adding the four labels which display the card names
        mygrid.add(lblcardEine, 1, 1);
        mygrid.add(lblcardZwei, 1, 2);
        mygrid.add(lblcardDrei, 1, 3);
        mygrid.add(lblcardVier, 1, 4);

        //Prompt 3diii - Label to prompt user for card guess
        Label prompter = new Label("Please guess a value between 4 and " + (int) (4 * maximum));
        mygrid.add(prompter, 3, 1, 2, 1);

        //Prompt 3div - Arranging extbox for user to enter their guess set-up
        mygrid.add(txtuserGuess, 3, 2, 2, 1);

        //Prompt 3dv - Buttons to flip cards and hide cards
        Button btnCardFlip = new Button("Flip the Cards");
        Button btnCardHide = new Button("Hide the Cards");
        //Event handler to control what occurs when button is pushed
        btnCardFlip.setOnAction(this::processFlipCards);
        btnCardHide.setOnAction(this::processHideCards);
        //Aligning buttons
        mygrid.add(btnCardFlip, 3, 3);
        mygrid.add(btnCardHide, 4, 3);
        GridPane.setHalignment(btnCardHide, HPos.RIGHT);

        //Prompt 3dvi - Labels to display items required
        Label lblSumCardtitle = new Label("The result was: ");
        Label lblWinLoosetitle = new Label("Have you won or lost?");
        //Aligning labels
        mygrid.add(lblSumCardtitle, 3, 4);
        mygrid.add(lblWinLoosetitle, 4, 4);
        mygrid.add(lblSumCard, 3, 5);
        mygrid.add(lblWinLoose, 4, 5);
        mygrid.add(lblWinNumber, 1, 5);

        /*Some variables may be declared on the class level. Please look there if 
        you cannot find them here. They also may be down below. */
        
        //Control what is shown in the program
        Scene controlScene = new Scene(mygrid);
        primaryStage.setScene(controlScene);
        primaryStage.show();

    }

    //Prompt 3e - Making an event for when btnCardFlip is pressed
    public void processFlipCards(ActionEvent event) {
        //Prompt 3ei - Get the user's guess from the textbox
        int guess = Integer.parseInt(txtuserGuess.getText());
        //Prompt 3eii - If statement that will run the game if the guess is viable
        if (guess >= 4 && guess < 4 * maximum) {
            //Flipping cards and getting random values from the Card class
            eineCard.flipCard();
            zweiCard.flipCard();
            dreiCard.flipCard();
            vierCard.flipCard();

            //Displaying the values from above in the appropriate labels
            lblcardEine.setText(Integer.toString(eineCard.getCardValue()));
            lblcardZwei.setText(Integer.toString(zweiCard.getCardValue()));
            lblcardDrei.setText(Integer.toString(dreiCard.getCardValue()));
            lblcardVier.setText(Integer.toString(vierCard.getCardValue()));

            //Summing up the values and putting them into the appropriate label
            int sumTotal = eineCard.getCardValue() + zweiCard.getCardValue()
                    + dreiCard.getCardValue() + vierCard.getCardValue();
            lblSumCard.setText(Integer.toString(sumTotal));

            //If statement to determine the condition of the guess as being right or wrong
            if (sumTotal == guess) {
                //Increment win counter
                wins++;
                //Prompt 3dvii - Label to display the number of wins
                lblWinNumber.setText("Wins: " + wins);
                //Display person is a winner
                lblWinLoose.setText("Winner!");
            } else {
                //Tell the person they've lost
                lblWinLoose.setText("Loser!");
            }
        } else {
            //Prompt 3eiii - Tell the person they've entered an illegal value
            lblWinLoose.setText("Not allowed son");
        }
    }

    //Prompt 3f- Making an event for whenCardHide is pressed 
    public void processHideCards(ActionEvent event) {
        //Prompt 3fi - Resetting the card values to what they were originally
        lblcardEine.setText("Card 1");
        lblcardZwei.setText("Card 2");
        lblcardDrei.setText("Card 3");
        lblcardVier.setText("Card 4");

        //Prompt 3fii - Clearing the label that declares you a winner or loser
        lblWinLoose.setText("");

        //Prompt 3fiii - Set guess textbox back to 0
        txtuserGuess.setText("0");

        //Clearing sum label
        lblSumCard.setText("");
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }

}
